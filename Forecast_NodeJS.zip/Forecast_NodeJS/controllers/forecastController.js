var history = require('../models/history')

exports.getForecast = function(req,res){
    history.find()
        .then(function(data){
            res.json(data);
        })
        .catch(function(){
            res.status(500).json({
                msg : 'something went wrong'
            })
        })
}

